package pixeldroid.app.mathcheckers;

import android.content.*;
import android.graphics.*;
import android.widget.*;
import android.app.*;

public class Chips
{
	public static Button unit1;
	public static Button unit2;
	public static Button unit3;
	public static Button unit4;
	public static Button unit5;
	public static Button unit6;
	public static Button unit7;
	public static Button unit8;
	public static Button unit9;
	public static Button unit10;
	public static Button unit11;
	public static Button unit12;
	public static Button unit13;
	public static Button unit14;
	public static Button unit15;
	public static Button unit16;
	public static Button unit17;
	public static Button unit18;
	public static Button unit19;
	public static Button unit20;
	public static Button unit21;
	public static Button unit22;
	public static Button unit23;
	public static Button unit24;
	public static Button unit25;
	public static Button unit26;
	public static Button unit27;
	public static Button unit28;
	public static Button unit29;
	public static Button unit30;
	public static Button unit31;
	public static Button unit32;
	
	public static class getChipP2
	{
		public static Bitmap chip(Context context)
		{
			Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.red_chip);
			return bitmap;
		}
	}

	public static class getChipP1
	{
		public static Bitmap chip(Context context)
		{
			Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.green_chip);
			return bitmap;
		}
	}
	
	public static void getButtons(Context context, Activity activity) {
		unit1 = (Button)activity.findViewById(R.id.unit1);
		unit2 = (Button)activity.findViewById(R.id.unit2);
		unit3 = (Button)activity.findViewById(R.id.unit3);
		unit4 = (Button)activity.findViewById(R.id.unit4);
		unit5 = (Button)activity.findViewById(R.id.unit5);
		unit6 = (Button)activity.findViewById(R.id.unit6);
		unit7 = (Button)activity.findViewById(R.id.unit7);
		unit8 = (Button)activity.findViewById(R.id.unit8);
		unit9 = (Button)activity.findViewById(R.id.unit9);
		unit10 = (Button)activity.findViewById(R.id.unit10);
		unit11 = (Button)activity.findViewById(R.id.unit11);
		unit12 = (Button)activity.findViewById(R.id.unit12);
		unit13 = (Button)activity.findViewById(R.id.unit13);
		unit14 = (Button)activity.findViewById(R.id.unit14);
		unit15 = (Button)activity.findViewById(R.id.unit15);
		unit16 = (Button)activity.findViewById(R.id.unit16);
		unit17 = (Button)activity.findViewById(R.id.unit17);
		unit18 = (Button)activity.findViewById(R.id.unit18);
		unit19 = (Button)activity.findViewById(R.id.unit19);
		unit20 = (Button)activity.findViewById(R.id.unit20);
		unit21 = (Button)activity.findViewById(R.id.unit21);
		unit22 = (Button)activity.findViewById(R.id.unit22);
		unit23 = (Button)activity.findViewById(R.id.unit23);
		unit24 = (Button)activity.findViewById(R.id.unit24);
		unit25 = (Button)activity.findViewById(R.id.unit25);
		unit26 = (Button)activity.findViewById(R.id.unit26);
		unit27 = (Button)activity.findViewById(R.id.unit27);
		unit28 = (Button)activity.findViewById(R.id.unit28);
		unit29 = (Button)activity.findViewById(R.id.unit29);
		unit30 = (Button)activity.findViewById(R.id.unit30);
		unit31 = (Button)activity.findViewById(R.id.unit31);
		unit32 = (Button)activity.findViewById(R.id.unit32);
		
		unit1.setBackgroundResource(R.drawable.red_chip);
		unit2.setBackgroundResource(R.drawable.red_chip);
		unit3.setBackgroundResource(R.drawable.red_chip);
		unit4.setBackgroundResource(R.drawable.red_chip);
		unit5.setBackgroundResource(R.drawable.red_chip);
		unit6.setBackgroundResource(R.drawable.red_chip);
		unit7.setBackgroundResource(R.drawable.red_chip);
		unit8.setBackgroundResource(R.drawable.red_chip);
		unit9.setBackgroundResource(R.drawable.red_chip);
		unit10.setBackgroundResource(R.drawable.red_chip);
		unit11.setBackgroundResource(R.drawable.red_chip);
		unit12.setBackgroundResource(R.drawable.red_chip);
		unit13.setBackgroundResource(R.drawable.blank);
		unit14.setBackgroundResource(R.drawable.blank);
		unit15.setBackgroundResource(R.drawable.blank);
		unit16.setBackgroundResource(R.drawable.blank);
		unit17.setBackgroundResource(R.drawable.blank);
		unit18.setBackgroundResource(R.drawable.blank);
		unit19.setBackgroundResource(R.drawable.blank);
		unit20.setBackgroundResource(R.drawable.blank);
		unit21.setBackgroundResource(R.drawable.green_chip);
		unit22.setBackgroundResource(R.drawable.green_chip);
		unit23.setBackgroundResource(R.drawable.green_chip);
		unit24.setBackgroundResource(R.drawable.green_chip);
		unit25.setBackgroundResource(R.drawable.green_chip);
		unit26.setBackgroundResource(R.drawable.green_chip);
		unit27.setBackgroundResource(R.drawable.green_chip);
		unit28.setBackgroundResource(R.drawable.green_chip);
		unit29.setBackgroundResource(R.drawable.green_chip);
		unit30.setBackgroundResource(R.drawable.green_chip);
		unit31.setBackgroundResource(R.drawable.green_chip);
		unit32.setBackgroundResource(R.drawable.green_chip);
		/*
		unit1.setAlpha(0);
		unit2.setAlpha(0);
		unit3.setAlpha(0);
		unit4.setAlpha(0);
		unit5.setAlpha(0);
		unit6.setAlpha(0);
		unit7.setAlpha(0);
		unit8.setAlpha(0);
		unit9.setAlpha(0);
		unit10.setAlpha(0);
		unit11.setAlpha(0);
		unit12.setAlpha(0);
		unit13.setAlpha(0);
		unit14.setAlpha(0);
		unit15.setAlpha(0);
		unit16.setAlpha(0);
		unit17.setAlpha(0);
		unit18.setAlpha(0);
		unit19.setAlpha(0);
		unit20.setAlpha(0);
		unit21.setAlpha(0);
		unit22.setAlpha(0);
		unit23.setAlpha(0);
		unit24.setAlpha(0);
		unit25.setAlpha(0);
		unit26.setAlpha(0);
		unit27.setAlpha(0);
		unit28.setAlpha(0);
		unit29.setAlpha(0);
		unit30.setAlpha(0);
		unit31.setAlpha(0);
		unit32.setAlpha(0);*/
	}
}

package pixeldroid.app.mathcheckers;

import android.app.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class ErrorHandler
{
	public static void show(final String exception) {
		final Activity activity = MainActivity.act;
		final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.error_dialog);
		
		EditText sput = (EditText)dialog.findViewById(R.id.errordialogOutput);
		
		sput.setText(exception);

        Button dialogButton = (Button)dialog.findViewById(R.id.errordialogClose);
        dialogButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
				}
			});

		Button dialogButton1 = (Button)dialog.findViewById(R.id.errordialogReport);
        dialogButton1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
					String emailList[] = {"pixeldroidmods@gmail.com"};
					Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
					intent.setType("message/rfc822");
					intent.putExtra(Intent.EXTRA_EMAIL, emailList);
					intent.putExtra(Intent.EXTRA_SUBJECT, "pixeldroid.app.dmath-Exception");
					intent.putExtra(Intent.EXTRA_TEXT, exception + "\nUser Feedback:\n");
					activity.startActivity(Intent.createChooser(intent,"Select a email service app"));
					
				}
			});

        dialog.show();
	}
}

package pixeldroid.app.mathcheckers;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import pixeldroid.app.mathcheckers.beta.*;
import android.view.animation.*;

public class MainActivity extends Activity 
{
	public static TextView titleName;
	public static Button pBtn;
	public static Button hBtn;
	public static Button sBtn;
	public static Button lBtn;
	public static Button bBtn;
	public static String locale;
	public static int state;
	public static Activity act;
	public static int sel;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		state = 0;
		act = MainActivity.this;
		getActionBar().hide();

		Toast.makeText(getBaseContext(), "Output: " + Pixeldroid.getDisplaySize.y(getBaseContext()), Toast.LENGTH_LONG).show();

		//titleBtn();

		//if(savedInstanceState==null) {
		try
		{
			locale = Pixeldroid.Data.readData("locale.txt", getBaseContext());
			if (locale == "NoExist")
			{
				Pixeldroid.Language.setLocale("en", getBaseContext());
				locale = "en";
			}
			else
			{
				Pixeldroid.Language.setLocale(locale, getBaseContext());
			}
		}
		catch (Exception e)
		{
			ErrorHandler.show(e.toString());
		}
		/*
		 } else {
		 try{
		 locale = savedInstanceState.getString("language");
		 Pixeldroid.Language.setLocale(locale, getBaseContext());
		 } catch (Exception e) {
		 Toast.makeText(getBaseContext(), "Error: " + e, Toast.LENGTH_LONG).show();
		 }
		 }*/
		mainBtns();
		//setBtns();
		ErrorHandler.show("made up exception");
    }

	@Override
	protected void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putString("language", locale);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onRestoreInstanceState(savedInstanceState);
		if (savedInstanceState != null)
		{
			locale = savedInstanceState.getString("language");
			Pixeldroid.Language.setLocale(locale, getBaseContext());
		}
	}

	public static void stop()
	{
		act.finish();
	}

    public static void mainBtns()
	{
		title();
		pBtn = (Button)act.findViewById(R.id.playBtn);
		hBtn = (Button)act.findViewById(R.id.helpBtn);
		sBtn = (Button)act.findViewById(R.id.settingsBtn);

		pBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					playBtn();
				}
			});

		hBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					helpBtn();
				}
			});

		sBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					settingsBtn();
				}
			});
	}

	public static void setBtns()
	{
		lBtn = (Button)act.findViewById(R.id.languageBtn);
		bBtn = (Button)act.findViewById(R.id.backBtn);

		lBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					languageBtn();
				}
			});
		bBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					act.setContentView(R.layout.main);
					mainBtns();
					Pixeldroid.Data.saveData("locale.txt", locale, act);
				}
			});
	}

	public static void title()
	{
		titleName = (TextView)act.findViewById(R.id.titleName);
		titleName.setTypeface(Pixeldroid.getFont(act.getAssets()));
	}

	public static void playBtn()
	{
		act.setContentView(R.layout.main_board);
		state = 1;
		Board.defineTiles(act.getBaseContext(), act);
		Chips.getButtons(act.getBaseContext(), act);
		Board.showChips(act.getBaseContext());
		DeviceDetails.show(act);
		Move.setLocations();
		provideBtn();
		//Board.loadBoard(getBaseContext(), getAssets());
	}

	public static void helpBtn()
	{

	}

	public static void settingsBtn()
	{
		act.setContentView(R.layout.main_settings);
		state = 3;
		setBtns();
	}

	public static void languageBtn()
	{
		PopupMenu dropMenu = new PopupMenu(act.getApplicationContext(), lBtn);
		dropMenu.getMenuInflater().inflate(R.menu.language_menu, dropMenu.getMenu());
		dropMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

				@Override
				public boolean onMenuItemClick(MenuItem menuItem)
				{
					int id = menuItem.getItemId();
					if (id == R.id.ar)
					{
						Pixeldroid.Language.setLocale("ar", act.getBaseContext());
						locale = "ar";
					}
					if (id == R.id.en)
					{
						Pixeldroid.Language.setLocale("en", act.getBaseContext());
						locale = "en";
					}
					if (id == R.id.es)
					{
						Pixeldroid.Language.setLocale("es", act.getBaseContext());
						locale = "es";
					}
					if (id == R.id.fr)
					{
						Pixeldroid.Language.setLocale("fr", act.getBaseContext());
						locale = "fr";
					}
					if (id == R.id.pt)
					{
						Pixeldroid.Language.setLocale("pt", act.getBaseContext());
						locale = "pt";
					}
					if (id == R.id.ru)
					{
						Pixeldroid.Language.setLocale("ru", act.getBaseContext());
						locale = "ru";
					}
					if (id == R.id.zh)
					{
						Pixeldroid.Language.setLocale("zh", act.getBaseContext());
						locale = "zh";
					}
					return true;
				}
			});
		dropMenu.show();
	}

	public static void provideBtn()
	{
		sel = 0;
		Chips.unit21.setOnClickListener(new OnClickListener() {
				public void onClick(View v)
				{
					if (Move.c21 && Move.t21 != 0)
					{
						sel = 21;
						Chips.unit21.setBackgroundResource(R.drawable.green_chip_green);
						goBtn();
					}
				}
			});
	}

	public static void goBtn()
	{
		if (sel != 0)
		{
			Chips.unit17.setOnClickListener(new OnClickListener() {
					public void onClick(View v)
					{
						Move.moveGreen(sel, 17);
						sel = 0;
					}
				});

			Chips.unit18.setOnClickListener(new OnClickListener() {
					public void onClick(View v)
					{
						Move.moveGreen(sel, 18);
						sel = 0;
					}
				});
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		if ((keyCode == KeyEvent.KEYCODE_BACK) && state == 0)
		{
			ViewDialog.showLeaveDialog(MainActivity.this, new Boolean(false));
			return true;
		}
		else if ((keyCode == KeyEvent.KEYCODE_BACK) && state == 1)
		{
			ViewDialog.showLeaveDialog(MainActivity.this, new Boolean(true));
			return true;
		}
		else if ((keyCode == KeyEvent.KEYCODE_BACK) && state == 2)
		{
			setContentView(R.layout.main);
			mainBtns();
			return true;
		}
		else if ((keyCode == KeyEvent.KEYCODE_BACK) && state == 3)
		{
			setContentView(R.layout.main);
			mainBtns();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

}

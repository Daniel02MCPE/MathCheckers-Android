package pixeldroid.app.mathcheckers;

import android.view.*;
import android.graphics.*;
import android.content.*;
import android.graphics.drawable.*;
import android.content.res.*;
import java.util.*;
import java.io.*;
import android.app.*;
import android.widget.*;

public class Pixeldroid
{
	//Created For pixeldroid.app.dmath
	public static class getDisplaySize
	{
		public static int x(Context context)
		{
			WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
			Display display = wm.getDefaultDisplay();
			Point size = new Point();
			display.getSize(size);
			int width = size.x;
			int height = size.y;
			return width;
		}
		public static int y(Context context)
		{
			WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
			Display display = wm.getDefaultDisplay();
			Point size = new Point();
			display.getSize(size);
			int width = size.x;
			int height = size.y;
			return height;
		}
	}
	public static class getBitmap
	{
		public static Bitmap convert(Context context, int resId)
		{
			Bitmap output = BitmapFactory.decodeResource(context.getResources(), resId);
			return output;
		}
		public static Bitmap overlay(Context context, int bgresId, int fgresId)
		{
			Resources r = context.getResources();
			Drawable[] layers = new Drawable[2];
			layers[0] = r.getDrawable(bgresId);
			layers[1] = r.getDrawable(fgresId);
			LayerDrawable layerDrawable = new LayerDrawable(layers);
			Bitmap bmOverlay = BitmapFactory.decodeResource(context.getResources(), R.drawable.blank);
			Canvas canvas = new Canvas(bmOverlay);
			layerDrawable.draw(canvas);

			return bmOverlay;
		}
		public static Bitmap create(int[] color, int sizex, int sizey)
		{
			Bitmap bitmap = Bitmap.createBitmap(color, sizex, sizey, Bitmap.Config.ARGB_8888);
			return bitmap;
		}
	}

	public static Typeface getFont(AssetManager am)
	{
		Typeface type = Typeface.createFromAsset(am, "fonts/Minecraftia.ttf");
		return type;
	}

	public static class Language
	{
		public static void setLocale(String lang, Context context)
		{
			Locale locale = new Locale(lang); 
			Locale.setDefault(locale);
			Configuration config = new Configuration();
			config.locale = locale;
			context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
		}
	}

	public static class Data
	{
		public static void saveData(String fileName, String value, Activity activity)
		{
			FileOutputStream outputStream;
			try
			{
				outputStream = activity.openFileOutput(fileName, Context.MODE_PRIVATE);
				outputStream.write(value.getBytes());
				outputStream.close();
			}
			catch (Exception e)
			{
				Toast.makeText(activity, "Error: " + e, Toast.LENGTH_LONG).show();
			}
		}
		public static String readData(String fileName, Context context)
		{
			StringBuilder sb = new StringBuilder();
			String st = new String("NoExist");
			try{
				FileInputStream fis = context.openFileInput(fileName);
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader bufferedReader = new BufferedReader(isr);
				String line;
				while ((line = bufferedReader.readLine()) != null)
				{
					sb.append(line);
				}
				}
				catch(IOException e) 
				{
					//Toast.makeText(context, "Error: " + e, Toast.LENGTH_LONG).show();
					return st;
				}
				return sb.toString();
			}
		}
	}

package pixeldroid.app.mathcheckers;

import android.app.*;
import android.view.*;
import android.widget.*;
import pixeldroid.app.mathcheckers.beta.*;

public class ViewDialog
{

    public static void showLeaveDialog(final Activity activity, final Boolean bool)
	{
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_leave);

        Button dialogButton = (Button)dialog.findViewById(R.id.dialogBtn1);
        dialogButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
				}
			});

		Button dialogButton1 = (Button)dialog.findViewById(R.id.dialogBtn2);
        dialogButton1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
					if (bool)
					{
						activity.setContentView(R.layout.main);
						MainActivity.mainBtns();
						DeviceDetails.hide();
					}
					else
					{
						MainActivity.stop();
					}
				}
			});

        dialog.show();

    }
}
